import Fastify from 'fastify';
import cors from '@fastify/cors';
import rateLimit from '@fastify/rate-limit';
import { config } from './config';
import { etfRoutes } from './routes/etfs';
import { newsRoutes } from './routes/news';
import { themeRoutes } from './routes/themes';
import { impactRoutes } from './routes/impact';
import { startCronJobs } from './jobs/scheduler';

const app = Fastify({
  logger: true,
});

async function bootstrap() {
  // Register plugins
  await app.register(cors, {
    origin: true,
    credentials: true,
  });

  await app.register(rateLimit, {
    max: 100,
    timeWindow: '1 minute',
  });

  // Health check
  app.get('/api/health', async () => {
    return { status: 'ok', timestamp: new Date().toISOString() };
  });

  // Register routes
  await app.register(etfRoutes, { prefix: '/api' });
  await app.register(newsRoutes, { prefix: '/api' });
  await app.register(themeRoutes, { prefix: '/api' });
  await app.register(impactRoutes, { prefix: '/api' });

  // Global error handler
  app.setErrorHandler((error, request, reply) => {
    app.log.error(error);
    reply.status(error.statusCode || 500).send({
      error: error.message || 'Internal Server Error',
      statusCode: error.statusCode || 500,
    });
  });

  // Start server
  try {
    await app.listen({ port: config.port, host: '0.0.0.0' });
    console.log(`🚀 API server running on http://localhost:${config.port}`);

    // Start background jobs
    startCronJobs();
  } catch (err) {
    app.log.error(err);
    process.exit(1);
  }
}

bootstrap();
