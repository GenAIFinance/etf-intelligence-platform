import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '../db';
import { etfService } from '../services/etf';
import { eodhdService } from '../services/eodhd';
import { llmClient } from '../services/llm';
import {
  etfQuerySchema,
  priceQuerySchema,
  metricsQuerySchema,
  tickerParamSchema,
  EtfQuery,
  PriceQuery,
  MetricsQuery,
  TickerParam,
  TrailingReturns,
} from '@etf-intelligence/shared';

export async function etfRoutes(fastify: FastifyInstance) {
  // GET /api/etfs - List ETFs with search and filters
  fastify.get('/etfs', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const query = etfQuerySchema.parse(request.query);
      const { search, assetClass, strategyType, page, pageSize } = query;
      
      // Parse AUM filters from query string
      const minAum = (request.query as any).minAum ? parseFloat((request.query as any).minAum) : undefined;
      const maxAum = (request.query as any).maxAum ? parseFloat((request.query as any).maxAum) : undefined;

      const where: any = {};

      if (search) {
        where.OR = [
          { ticker: { contains: search.toUpperCase() } },
          { name: { contains: search } },
        ];
      }

      if (assetClass) {
        where.assetClass = assetClass;
      }

      if (strategyType) {
        where.strategyType = { contains: strategyType };
      }
      
      // Add AUM filtering
      if (minAum !== undefined || maxAum !== undefined) {
        where.aum = {};
        if (minAum !== undefined) {
          where.aum.gte = minAum;
        }
        if (maxAum !== undefined && !isNaN(maxAum) && isFinite(maxAum)) {
          where.aum.lte = maxAum;
        }
      }

      const [etfs, total] = await Promise.all([
        prisma.etf.findMany({
          where,
          skip: (page - 1) * pageSize,
          take: pageSize,
          orderBy: { ticker: 'asc' },
          include: {
            sectorWeights: {
              orderBy: { weight: 'desc' },
              take: 5,
            },
          },
        }),
        prisma.etf.count({ where }),
      ]);

      return {
        data: etfs,
        page,
        pageSize,
        total,
        totalPages: Math.ceil(total / pageSize),
      };
    } catch (error: any) {
      reply.status(400).send({ error: error.message });
    }
  });

  // GET /api/etfs/:ticker - Get ETF details
  fastify.get('/etfs/:ticker', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { ticker } = tickerParamSchema.parse(request.params);

      let etf = await prisma.etf.findUnique({
        where: { ticker },
        include: {
          sectorWeights: { orderBy: { weight: 'desc' } },
        },
      });

      // If not in DB, try to fetch from EODHD
      if (!etf) {
        const synced = await etfService.syncEtf(ticker);
        if (!synced) {
          return reply.status(404).send({ error: 'ETF not found' });
        }
        etf = await prisma.etf.findUnique({
          where: { ticker },
          include: {
            sectorWeights: { orderBy: { weight: 'desc' } },
          },
        });
      }

      // Get LLM summary if enabled
      let llmSummary = null;
      if (etf && llmClient.isEnabled()) {
        const holdings = await prisma.etfHolding.findMany({
          where: { etfId: etf.id },
          orderBy: { weight: 'desc' },
          take: 10,
        });

        llmSummary = await llmClient.summarizeEtf(
          etf.name,
          etf.summary || '',
          etf.assetClass || '',
          etf.strategyType || '',
          holdings.map((h) => ({ name: h.holdingName, weight: h.weight })),
          etf.sectorWeights.map((s) => ({ sector: s.sector, weight: s.weight }))
        );
      }

      return { ...etf, llmSummary };
    } catch (error: any) {
      reply.status(400).send({ error: error.message });
    }
  });

  // GET /api/etfs/:ticker/holdings - Get ETF holdings
  fastify.get('/etfs/:ticker/holdings', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { ticker } = tickerParamSchema.parse(request.params);

      const etf = await prisma.etf.findUnique({ where: { ticker } });
      if (!etf) {
        return reply.status(404).send({ error: 'ETF not found' });
      }

      const holdings = await prisma.etfHolding.findMany({
        where: { etfId: etf.id },
        orderBy: { weight: 'desc' },
      });

      const concentration = await etfService.getConcentrationMetrics(ticker);

      return {
        holdings,
        concentration,
      };
    } catch (error: any) {
      reply.status(400).send({ error: error.message });
    }
  });

  // GET /api/etfs/:ticker/sectors - Get ETF sector weights
  fastify.get('/etfs/:ticker/sectors', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { ticker } = tickerParamSchema.parse(request.params);

      const etf = await prisma.etf.findUnique({ where: { ticker } });
      if (!etf) {
        return reply.status(404).send({ error: 'ETF not found' });
      }

      const sectors = await prisma.etfSectorWeight.findMany({
        where: { etfId: etf.id },
        orderBy: { weight: 'desc' },
      });

      return { sectors };
    } catch (error: any) {
      reply.status(400).send({ error: error.message });
    }
  });

  // GET /api/etfs/:ticker/prices - Get price history
  fastify.get('/etfs/:ticker/prices', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { ticker } = tickerParamSchema.parse(request.params);
      const { range, interval } = priceQuerySchema.parse(request.query);

      // Calculate date range
      const today = new Date();
      const fromDate = new Date();

      switch (range) {
        case '1m':
          fromDate.setMonth(fromDate.getMonth() - 1);
          break;
        case '3m':
          fromDate.setMonth(fromDate.getMonth() - 3);
          break;
        case '6m':
          fromDate.setMonth(fromDate.getMonth() - 6);
          break;
        case '1y':
          fromDate.setFullYear(fromDate.getFullYear() - 1);
          break;
        case '3y':
          fromDate.setFullYear(fromDate.getFullYear() - 3);
          break;
        case '5y':
          fromDate.setFullYear(fromDate.getFullYear() - 5);
          break;
      }

      let prices = await prisma.priceBar.findMany({
        where: {
          symbol: ticker,
          date: { gte: fromDate, lte: today },
        },
        orderBy: { date: 'asc' },
      });

      // If no prices in DB, fetch from EODHD
      if (prices.length === 0) {
        await etfService.syncPrices(ticker);
        prices = await prisma.priceBar.findMany({
          where: {
            symbol: ticker,
            date: { gte: fromDate, lte: today },
          },
          orderBy: { date: 'asc' },
        });
      }

      // Aggregate to weekly if requested
      if (interval === '1w') {
        const weeklyPrices: typeof prices = [];
        let weekStart: Date | null = null;
        let weekData: typeof prices[0] | null = null;

        for (const price of prices) {
          const dayOfWeek = price.date.getDay();
          if (dayOfWeek === 1 || !weekStart) {
            // Monday or first price
            if (weekData) weeklyPrices.push(weekData);
            weekStart = price.date;
            weekData = { ...price };
          } else if (weekData) {
            weekData.high = Math.max(weekData.high, price.high);
            weekData.low = Math.min(weekData.low, price.low);
            weekData.close = price.close;
            weekData.adjustedClose = price.adjustedClose;
            weekData.volume += price.volume;
          }
        }
        if (weekData) weeklyPrices.push(weekData);
        prices = weeklyPrices;
      }

      return { prices, range, interval };
    } catch (error: any) {
      reply.status(400).send({ error: error.message });
    }
  });

  // GET /api/etfs/:ticker/metrics - Get metrics snapshot
  fastify.get('/etfs/:ticker/metrics', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { ticker } = tickerParamSchema.parse(request.params);
      const { asOf } = metricsQuerySchema.parse(request.query);

      const etf = await prisma.etf.findUnique({ where: { ticker } });
      if (!etf) {
        return reply.status(404).send({ error: 'ETF not found' });
      }

      let metrics = await prisma.etfMetricSnapshot.findFirst({
        where: {
          etfId: etf.id,
          ...(asOf ? { asOfDate: { lte: new Date(asOf) } } : {}),
        },
        orderBy: { asOfDate: 'desc' },
      });

      // Calculate if not available
      if (!metrics) {
        await etfService.syncPrices(ticker);
        await etfService.calculateMetrics(ticker);
        metrics = await prisma.etfMetricSnapshot.findFirst({
          where: { etfId: etf.id },
          orderBy: { asOfDate: 'desc' },
        });
      }

      if (!metrics) {
        return reply.status(404).send({ error: 'Metrics not available' });
      }

      const trailingReturns = JSON.parse(metrics.trailingReturnsJson) as TrailingReturns;

      return {
        ticker,
        asOfDate: metrics.asOfDate.toISOString(),
        trailingReturns,
        riskMetrics: {
          volatility: metrics.volatility,
          sharpe: metrics.sharpe,
          maxDrawdown: metrics.maxDrawdown,
          beta: metrics.beta,
        },
        technicals: {
          latestPrice: metrics.latestPrice,
          rsi14: metrics.rsi14,
          ma20: metrics.ma20,
          ma50: metrics.ma50,
          ma200: metrics.ma200,
          hi52w: metrics.hi52w,
          lo52w: metrics.lo52w,
        },
      };
    } catch (error: any) {
      reply.status(400).send({ error: error.message });
    }
  });

  // GET /api/etfs/:ticker/themes-exposure - Get theme exposures
  fastify.get('/etfs/:ticker/themes-exposure', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { ticker } = tickerParamSchema.parse(request.params);

      const exposures = await etfService.getThemeExposures(ticker);

      return { ticker, exposures };
    } catch (error: any) {
      reply.status(400).send({ error: error.message });
    }
  });
}
