import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '../db';
import { newsService } from '../services/news';
import { newsQuerySchema, manualNewsSchema, NewsQuery, ManualNewsBody } from '@etf-intelligence/shared';

export async function newsRoutes(fastify: FastifyInstance) {
  // GET /api/news - Get news with filters
  fastify.get('/news', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const query = newsQuerySchema.parse(request.query);
      const { query: searchQuery, ticker, theme, from, to, page, pageSize } = query;

      const where: any = {};

      if (searchQuery) {
        where.OR = [
          { title: { contains: searchQuery } },
          { snippet: { contains: searchQuery } },
        ];
      }

      if (from) {
        where.publishedAt = { ...where.publishedAt, gte: new Date(from) };
      }

      if (to) {
        where.publishedAt = { ...where.publishedAt, lte: new Date(to) };
      }

      // If ticker filter, find news items that impact that ETF
      if (ticker) {
        const etf = await prisma.etf.findUnique({ where: { ticker } });
        if (etf) {
          const impacts = await prisma.newsImpact.findMany({
            where: { etfId: etf.id },
            select: { newsItemId: true },
          });
          where.id = { in: impacts.map((i) => i.newsItemId) };
        }
      }

      // If theme filter, find news items with that topic
      if (theme) {
        const topics = await prisma.newsTopic.findMany({
          where: { topicLabel: { contains: theme } },
          select: { newsItemId: true },
        });
        where.id = { in: topics.map((t) => t.newsItemId) };
      }

      const [newsItems, total] = await Promise.all([
        prisma.newsItem.findMany({
          where,
          skip: (page - 1) * pageSize,
          take: pageSize,
          orderBy: { publishedAt: 'desc' },
          include: {
            topics: true,
            impacts: {
              include: {
                etf: { select: { ticker: true, name: true } },
              },
              take: 5,
            },
          },
        }),
        prisma.newsItem.count({ where }),
      ]);

      return {
        data: newsItems.map((item) => ({
          ...item,
          topics: item.topics.map((t) => ({
            ...t,
            keywords: JSON.parse(t.keywordsJson),
          })),
          impacts: item.impacts.map((i) => ({
            etfTicker: i.etf.ticker,
            etfName: i.etf.name,
            impactScore: i.impactScore,
            rationale: i.rationale,
            matchedHoldings: JSON.parse(i.matchedHoldingsJson),
            matchedThemes: JSON.parse(i.matchedThemesJson),
          })),
        })),
        page,
        pageSize,
        total,
        totalPages: Math.ceil(total / pageSize),
      };
    } catch (error: any) {
      reply.status(400).send({ error: error.message });
    }
  });

  // POST /api/news/manual - Manually add news item
  fastify.post('/news/manual', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const body = manualNewsSchema.parse(request.body);

      const newsItemId = await newsService.processAndStoreNews({
        source: body.source,
        title: body.title,
        url: body.url,
        publishedAt: body.publishedAt ? new Date(body.publishedAt) : new Date(),
        snippet: body.snippet,
      });

      if (!newsItemId) {
        return reply.status(400).send({ error: 'Failed to store news item' });
      }

      const newsItem = await prisma.newsItem.findUnique({
        where: { id: newsItemId },
        include: { topics: true },
      });

      return {
        message: 'News item added successfully',
        newsItem: {
          ...newsItem,
          topics: newsItem?.topics.map((t) => ({
            ...t,
            keywords: JSON.parse(t.keywordsJson),
          })),
        },
      };
    } catch (error: any) {
      reply.status(400).send({ error: error.message });
    }
  });

  // GET /api/news/trending - Get trending topics
  fastify.get('/news/trending', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const topics = await newsService.getTrendingTopics(7);
      return { topics };
    } catch (error: any) {
      reply.status(400).send({ error: error.message });
    }
  });
}
