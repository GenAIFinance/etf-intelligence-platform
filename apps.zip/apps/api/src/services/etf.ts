import { prisma } from '../db';
import { eodhdService } from './eodhd';
import { CacheService } from './cache';
import { config } from '../config';
import {
  calculateTrailingReturns,
  calculateVolatility,
  calculateSharpe,
  calculateMaxDrawdown,
  calculateBeta,
  calculateRSI,
  calculateMA,
  calculate52WeekHighLow,
  calculateHHI,
  calculateTop10Weight,
} from './metrics';
import { classifyHolding, THEME_TAXONOMY, ThemeExposure } from '@etf-intelligence/shared';

function determineAssetClass(general: any, etfData: any): string | null {
  // Method 1: Use Asset Allocation if available
  if (etfData?.Asset_Allocation?.Stock?.Net_Assets_Percentage) {
    const stockPercentage = parseFloat(etfData.Asset_Allocation.Stock.Net_Assets_Percentage);
    if (stockPercentage > 50) return 'Equity';
    
    const bondPercentage = etfData?.Asset_Allocation?.Bond?.Net_Assets_Percentage 
      ? parseFloat(etfData.Asset_Allocation.Bond.Net_Assets_Percentage) 
      : 0;
    if (bondPercentage > 50) return 'Fixed Income';
    
    return 'Mixed Allocation';
  }

  // Method 2: Use Category field as fallback
  const category = (general.Category || '').toLowerCase();
  
  if (category.match(/equity|stock|growth|value|blend|large|mid|small|cap/i)) {
    return 'Equity';
  }
  if (category.match(/bond|fixed income|treasury|municipal|corporate debt/i)) {
    return 'Fixed Income';
  }
  if (category.match(/commodity|gold|silver|oil|energy|metal/i)) {
    return 'Commodity';
  }
  if (category.match(/real estate|reit/i)) {
    return 'Real Estate';
  }
  if (category.match(/currency|forex|volatility|vix|inverse|leveraged|short/i)) {
    return 'Alternative';
  }
  if (category.match(/allocation|balanced|target date|target risk|moderate/i)) {
    return 'Mixed Allocation';
  }
  
  return null;
}

export class EtfService {
  // Sync ETF data from EODHD to database
  async syncEtf(ticker: string): Promise<boolean> {
    try {
      const fundamentals = await eodhdService.getEtfFundamentals(ticker);
      if (!fundamentals) return false;

      const general = fundamentals.General;
      const etfData = fundamentals.ETF_Data;

      // Convert turnover and aum to numbers (EODHD returns them as strings)
      const turnover = etfData?.AnnualHoldingsTurnover 
        ? parseFloat(String(etfData.AnnualHoldingsTurnover)) 
        : null;
      const aum = etfData?.TotalAssets 
        ? parseFloat(String(etfData.TotalAssets)) 
        : null;

      // Upsert ETF
      const etf = await prisma.etf.upsert({
        where: { ticker },
        create: {
          ticker,
          name: general.Name,
          exchange: general.Exchange,
          country: general.CountryName,
          currency: general.CurrencyCode,
          assetClass: determineAssetClass(general, etfData),
          strategyType: general.Category || null,
          summary: general.Description || null,
          turnover,
          aum,
          inceptionDate: etfData?.Inception_Date ? new Date(etfData.Inception_Date) : null,
        },
        update: {
          name: general.Name,
          assetClass: determineAssetClass(general, etfData),
          strategyType: general.Category || null,
          summary: general.Description || null,
          turnover: etfData?.AnnualHoldingsTurnover ? parseFloat(etfData.AnnualHoldingsTurnover) : null,
          aum: etfData?.TotalAssets ? parseFloat(etfData.TotalAssets) : null,
          updatedAt: new Date(),
        },
      });

      // Sync sector weights
      if (etfData?.Sector_Weights) {
        const asOfDate = new Date();
        for (const [sector, data] of Object.entries(etfData.Sector_Weights)) {
          // Note: EODHD uses 'Equity_%' not 'Equity_Percentage'
          const equityPercent = (data as any)['Equity_%'] || (data as any).Equity_Percentage || '0';
          const weight = parseFloat(equityPercent) / 100;
          if (weight > 0) {
            await prisma.etfSectorWeight.upsert({
              where: {
                etfId_sector_asOfDate: { etfId: etf.id, sector, asOfDate },
              },
              create: { etfId: etf.id, sector, weight, asOfDate },
              update: { weight },
            });
          }
        }
      }

      // Sync holdings
      if (etfData?.Holdings) {
        const asOfDate = new Date();
        for (const [_, holding] of Object.entries(etfData.Holdings)) {
          const h = holding as any;
          // Note: EODHD uses 'Assets_%' not 'Assets_Percentage'
          const assetsPercent = h['Assets_%'] || h.Assets_Percentage || 0;
          if (h.Code && assetsPercent > 0) {
            await prisma.etfHolding.upsert({
              where: {
                etfId_holdingTicker_asOfDate: {
                  etfId: etf.id,
                  holdingTicker: h.Code,
                  asOfDate,
                },
              },
              create: {
                etfId: etf.id,
                holdingTicker: h.Code,
                holdingName: h.Name || h.Code,
                weight: assetsPercent / 100,
                sector: h.Sector || null,
                industry: h.Industry || null,
                asOfDate,
              },
              update: {
                holdingName: h.Name || h.Code,
                weight: assetsPercent / 100,
                sector: h.Sector || null,
                industry: h.Industry || null,
              },
            });

            // Classify holding into themes
            const themes = classifyHolding(h.Name || '', h.Code, h.Sector, h.Industry);
            if (themes.length > 0) {
              await prisma.holdingClassification.upsert({
                where: {
                  etfId_holdingTicker: { etfId: etf.id, holdingTicker: h.Code },
                },
                create: {
                  etfId: etf.id,
                  holdingTicker: h.Code,
                  holdingName: h.Name || h.Code,
                  themesJson: JSON.stringify(themes),
                },
                update: {
                  themesJson: JSON.stringify(themes),
                  classifiedAt: new Date(),
                },
              });
            }
          }
        }
      }

      return true;
    } catch (error) {
      console.error(`Failed to sync ETF ${ticker}:`, error);
      return false;
    }
  }

  // Sync price data
  async syncPrices(ticker: string): Promise<boolean> {
    try {
      const fiveYearsAgo = new Date();
      fiveYearsAgo.setFullYear(fiveYearsAgo.getFullYear() - 5);
      const today = new Date();

      const prices = await eodhdService.getHistoricalPrices(
        ticker,
        fiveYearsAgo.toISOString().split('T')[0],
        today.toISOString().split('T')[0]
      );

      for (const price of prices) {
        const date = new Date(price.date);
        await prisma.priceBar.upsert({
          where: {
            symbol_date: { symbol: ticker, date },
          },
          create: {
            symbol: ticker,
            date,
            open: price.open,
            high: price.high,
            low: price.low,
            close: price.close,
            volume: price.volume,
            adjustedClose: price.adjusted_close,
          },
          update: {
            open: price.open,
            high: price.high,
            low: price.low,
            close: price.close,
            volume: price.volume,
            adjustedClose: price.adjusted_close,
          },
        });
      }

      return true;
    } catch (error) {
      console.error(`Failed to sync prices for ${ticker}:`, error);
      return false;
    }
  }

  // Calculate and store metrics
  async calculateMetrics(ticker: string): Promise<boolean> {
    try {
      const etf = await prisma.etf.findUnique({ where: { ticker } });
      if (!etf) return false;

      // Get prices
      const prices = await prisma.priceBar.findMany({
        where: { symbol: ticker },
        orderBy: { date: 'desc' },
      });

      if (prices.length < 20) return false;

      const pricePoints = prices.map((p) => ({
        date: p.date,
        close: p.close,
        adjustedClose: p.adjustedClose,
      }));

      // Get benchmark prices
      const benchmarkPrices = await prisma.priceBar.findMany({
        where: { symbol: config.benchmarkTicker },
        orderBy: { date: 'desc' },
      });

      const benchmarkPoints = benchmarkPrices.map((p) => ({
        date: p.date,
        close: p.close,
        adjustedClose: p.adjustedClose,
      }));

      // Calculate all metrics
      const trailingReturns = calculateTrailingReturns(pricePoints);
      const volatility = calculateVolatility(pricePoints);
      const sharpe = calculateSharpe(pricePoints);
      const maxDrawdown = calculateMaxDrawdown(pricePoints);
      const beta = calculateBeta(pricePoints, benchmarkPoints);
      const rsi14 = calculateRSI(pricePoints);
      const ma20 = calculateMA(pricePoints, 20);
      const ma50 = calculateMA(pricePoints, 50);
      const ma200 = calculateMA(pricePoints, 200);
      const { high: hi52w, low: lo52w } = calculate52WeekHighLow(pricePoints);
      const latestPrice = pricePoints[0]?.adjustedClose || null;

      const asOfDate = new Date();
      asOfDate.setHours(0, 0, 0, 0);

      await prisma.etfMetricSnapshot.upsert({
        where: {
          etfId_asOfDate: { etfId: etf.id, asOfDate },
        },
        create: {
          etfId: etf.id,
          asOfDate,
          trailingReturnsJson: JSON.stringify(trailingReturns),
          volatility,
          sharpe,
          maxDrawdown,
          beta,
          rsi14,
          ma20,
          ma50,
          ma200,
          hi52w,
          lo52w,
          latestPrice,
        },
        update: {
          trailingReturnsJson: JSON.stringify(trailingReturns),
          volatility,
          sharpe,
          maxDrawdown,
          beta,
          rsi14,
          ma20,
          ma50,
          ma200,
          hi52w,
          lo52w,
          latestPrice,
        },
      });

      return true;
    } catch (error) {
      console.error(`Failed to calculate metrics for ${ticker}:`, error);
      return false;
    }
  }

  // Get theme exposures for an ETF
  async getThemeExposures(ticker: string): Promise<ThemeExposure[]> {
    const etf = await prisma.etf.findUnique({ where: { ticker } });
    if (!etf) return [];

    const classifications = await prisma.holdingClassification.findMany({
      where: { etfId: etf.id },
    });

    const holdings = await prisma.etfHolding.findMany({
      where: { etfId: etf.id },
      orderBy: { asOfDate: 'desc' },
    });

    // Build theme exposures
    const themeMap: Map<string, { exposure: number; holdings: { ticker: string; name: string; weight: number; confidence: number }[] }> = new Map();

    // Initialize all themes
    for (const theme of THEME_TAXONOMY) {
      themeMap.set(theme.id, { exposure: 0, holdings: [] });
    }

    // Process classifications
    for (const classification of classifications) {
      const themes = JSON.parse(classification.themesJson) as { themeId: string; confidence: number }[];
      const holding = holdings.find((h) => h.holdingTicker === classification.holdingTicker);
      const weight = holding?.weight || 0;

      for (const { themeId, confidence } of themes) {
        const themeData = themeMap.get(themeId);
        if (themeData) {
          themeData.exposure += weight * confidence;
          themeData.holdings.push({
            ticker: classification.holdingTicker,
            name: classification.holdingName,
            weight,
            confidence,
          });
        }
      }
    }

    // Convert to array and sort
    const exposures: ThemeExposure[] = [];
    for (const [themeId, data] of themeMap.entries()) {
      const theme = THEME_TAXONOMY.find((t) => t.id === themeId);
      if (theme && data.exposure > 0) {
        exposures.push({
          themeId,
          themeName: theme.name,
          exposure: data.exposure,
          holdings: data.holdings.sort((a, b) => b.weight - a.weight).slice(0, 20),
        });
      }
    }

    return exposures.sort((a, b) => b.exposure - a.exposure);
  }

  // Get concentration metrics
  async getConcentrationMetrics(ticker: string): Promise<{
    top10Weight: number;
    hhi: number;
    totalHoldings: number;
  } | null> {
    const etf = await prisma.etf.findUnique({ where: { ticker } });
    if (!etf) return null;

    const holdings = await prisma.etfHolding.findMany({
      where: { etfId: etf.id },
      orderBy: { weight: 'desc' },
    });

    if (holdings.length === 0) return null;

    const weights = holdings.map((h) => h.weight);

    return {
      top10Weight: calculateTop10Weight(weights),
      hhi: calculateHHI(weights),
      totalHoldings: holdings.length,
    };
  }
}

export const etfService = new EtfService();
