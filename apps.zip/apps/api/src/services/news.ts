import Parser from 'rss-parser';
import { prisma } from '../db';
import { llmClient } from './llm';
import { GOOGLE_NEWS_RSS_BASE, TOPIC_LABELS } from '@etf-intelligence/shared';

const parser = new Parser({
  customFields: {
    item: ['source'],
  },
});

export class NewsService {
  // Fetch news from Google News RSS
  async fetchGoogleNews(query: string): Promise<{
    title: string;
    link: string;
    pubDate: string;
    contentSnippet?: string;
    source?: string;
  }[]> {
    try {
      const encodedQuery = encodeURIComponent(query);
      const rssUrl = `${GOOGLE_NEWS_RSS_BASE}?q=${encodedQuery}&hl=en-US&gl=US&ceid=US:en`;

      const feed = await parser.parseURL(rssUrl);

      return (feed.items || []).map((item) => ({
        title: item.title || '',
        link: item.link || '',
        pubDate: item.pubDate || new Date().toISOString(),
        contentSnippet: item.contentSnippet,
        source: (item as any).source?.['$']?.url || 'Google News',
      }));
    } catch (error) {
      console.error(`Failed to fetch news for query: ${query}`, error);
      return [];
    }
  }

  // Store news item and extract topics
  async processAndStoreNews(newsItem: {
    source: string;
    title: string;
    url: string;
    publishedAt: Date;
    snippet?: string;
  }): Promise<number | null> {
    try {
      // Check if already exists
      const existing = await prisma.newsItem.findUnique({
        where: { url: newsItem.url },
      });

      if (existing) return existing.id;

      // Create news item
      const created = await prisma.newsItem.create({
        data: {
          source: newsItem.source,
          title: newsItem.title,
          url: newsItem.url,
          publishedAt: newsItem.publishedAt,
          snippet: newsItem.snippet || null,
        },
      });

      // Extract topics
      const topics = this.extractTopics(newsItem.title, newsItem.snippet || '');

      for (const topic of topics) {
        await prisma.newsTopic.create({
          data: {
            newsItemId: created.id,
            topicLabel: topic.label,
            keywordsJson: JSON.stringify(topic.keywords),
          },
        });
      }

      return created.id;
    } catch (error) {
      console.error('Failed to store news item:', error);
      return null;
    }
  }

  // Simple TF-IDF-like keyword extraction
  private extractTopics(title: string, snippet: string): { label: string; keywords: string[] }[] {
    const text = `${title} ${snippet}`.toLowerCase();
    const results: { label: string; keywords: string[] }[] = [];

    // Topic keyword mappings
    const topicKeywords: Record<string, string[]> = {
      'FDA Regulation': ['fda', 'approval', 'regulatory', 'drug approval', 'clinical'],
      'AI Chip Export Controls': ['chip', 'export', 'nvidia', 'semiconductor', 'china', 'ai chip'],
      'Interest Rate Decision': ['interest rate', 'fed', 'federal reserve', 'rate cut', 'rate hike', 'powell', 'fomc'],
      'Earnings Report': ['earnings', 'quarterly', 'revenue', 'profit', 'beat', 'miss', 'eps'],
      'Merger & Acquisition': ['merger', 'acquisition', 'buyout', 'deal', 'takeover', 'm&a'],
      'Clinical Trial Results': ['clinical trial', 'phase 3', 'phase 2', 'trial results', 'efficacy'],
      'Product Launch': ['launch', 'release', 'unveil', 'announce', 'new product'],
      'Executive Changes': ['ceo', 'cfo', 'executive', 'resign', 'appoint', 'leadership'],
      'Supply Chain Issues': ['supply chain', 'shortage', 'logistics', 'delivery', 'manufacturing'],
      'Antitrust Investigation': ['antitrust', 'doj', 'ftc', 'monopoly', 'investigation', 'lawsuit'],
      'Trade Policy': ['tariff', 'trade war', 'import', 'export ban', 'sanctions'],
      'Economic Data': ['gdp', 'inflation', 'unemployment', 'economic', 'jobs report', 'cpi'],
      'Geopolitical Risk': ['war', 'conflict', 'geopolitical', 'russia', 'ukraine', 'taiwan'],
      'Climate Policy': ['climate', 'carbon', 'emissions', 'green', 'esg', 'renewable'],
      'Data Privacy': ['privacy', 'data breach', 'gdpr', 'security', 'hack'],
      'Labor Market': ['layoff', 'hiring', 'workforce', 'strike', 'union'],
      'Energy Prices': ['oil price', 'gas price', 'opec', 'crude', 'energy'],
      'Currency Movement': ['dollar', 'forex', 'currency', 'exchange rate', 'yen', 'euro'],
      'IPO/SPAC': ['ipo', 'spac', 'public offering', 'debut', 'listing'],
      'Bankruptcy/Restructuring': ['bankruptcy', 'chapter 11', 'restructuring', 'default', 'insolvency'],
    };

    for (const [label, keywords] of Object.entries(topicKeywords)) {
      const matchedKeywords = keywords.filter((kw) => text.includes(kw));
      if (matchedKeywords.length > 0) {
        results.push({ label, keywords: matchedKeywords });
      }
    }

    return results;
  }

  // Calculate impact score for an ETF based on news
  async calculateImpact(
    newsItemId: number,
    etfId: number,
    etfHoldings: { ticker: string; name: string; weight: number }[],
    etfThemes: { themeId: string; exposure: number }[]
  ): Promise<{ score: number; matchedHoldings: string[]; matchedThemes: string[]; rationale: string }> {
    const newsItem = await prisma.newsItem.findUnique({
      where: { id: newsItemId },
      include: { topics: true },
    });

    if (!newsItem) {
      return { score: 0, matchedHoldings: [], matchedThemes: [], rationale: 'News item not found' };
    }

    const text = `${newsItem.title} ${newsItem.snippet || ''}`.toLowerCase();
    const matchedHoldings: string[] = [];
    const matchedThemes: string[] = [];
    let relevanceScore = 0;

    // Check for holding mentions
    for (const holding of etfHoldings) {
      const tickerMatch = text.includes(holding.ticker.toLowerCase());
      const nameMatch = holding.name.split(' ').some((word) =>
        word.length > 3 && text.includes(word.toLowerCase())
      );

      if (tickerMatch || nameMatch) {
        matchedHoldings.push(holding.ticker);
        relevanceScore += holding.weight * 100; // Weight contribution
      }
    }

    // Check for theme alignment
    const topics = newsItem.topics.map((t) => t.topicLabel.toLowerCase());
    const themeTopicMap: Record<string, string[]> = {
      'ai-ml': ['ai chip export controls', 'product launch'],
      'semiconductors': ['ai chip export controls', 'supply chain issues'],
      'healthcare-biotech': ['fda regulation', 'clinical trial results'],
      'fintech': ['interest rate decision', 'economic data'],
      'clean-energy': ['climate policy', 'energy prices'],
      'ev-battery': ['climate policy', 'supply chain issues'],
    };

    for (const theme of etfThemes) {
      const relatedTopics = themeTopicMap[theme.themeId] || [];
      const hasMatch = relatedTopics.some((t) =>
        topics.some((topic) => topic.includes(t) || t.includes(topic))
      );

      if (hasMatch) {
        matchedThemes.push(theme.themeId);
        relevanceScore += theme.exposure * 50;
      }
    }

    // Normalize score to 0-100
    const normalizedScore = Math.min(100, relevanceScore);

    // Generate rationale
    let rationale = '';
    if (matchedHoldings.length > 0) {
      rationale += `News mentions holdings: ${matchedHoldings.join(', ')}. `;
    }
    if (matchedThemes.length > 0) {
      rationale += `Affects themes: ${matchedThemes.join(', ')}. `;
    }
    if (!rationale) {
      rationale = 'No direct impact identified.';
    }

    return {
      score: normalizedScore,
      matchedHoldings,
      matchedThemes,
      rationale,
    };
  }

  // Get trending topics
  async getTrendingTopics(days: number = 7): Promise<{ topic: string; count: number }[]> {
    const since = new Date();
    since.setDate(since.getDate() - days);

    const topics = await prisma.newsTopic.findMany({
      where: {
        newsItem: {
          publishedAt: { gte: since },
        },
      },
      select: {
        topicLabel: true,
      },
    });

    const counts: Record<string, number> = {};
    for (const t of topics) {
      counts[t.topicLabel] = (counts[t.topicLabel] || 0) + 1;
    }

    return Object.entries(counts)
      .map(([topic, count]) => ({ topic, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }
}

export const newsService = new NewsService();
