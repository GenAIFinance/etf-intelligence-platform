import { LRUCache } from 'lru-cache';
import { prisma } from '../db';
import { config } from '../config';

// In-memory LRU cache
const memoryCache = new LRUCache<string, unknown>({
  max: 1000,
  ttl: 1000 * 60 * 5, // 5 minutes default
});

export class CacheService {
  // Get from memory cache first, then DB cache
  static async get<T>(key: string): Promise<T | null> {
    // Check memory cache first
    const memCached = memoryCache.get(key);
    if (memCached !== undefined) {
      return memCached as T;
    }

    // Check DB cache
    try {
      const dbCached = await prisma.apiCache.findUnique({
        where: { key },
      });

      if (dbCached) {
        const fetchedAt = new Date(dbCached.fetchedAt).getTime();
        const expiresAt = fetchedAt + dbCached.ttlSeconds * 1000;

        if (Date.now() < expiresAt) {
          const value = JSON.parse(dbCached.valueJson) as T;
          // Store in memory cache for faster access
          memoryCache.set(key, value);
          return value;
        } else {
          // Expired, delete from DB
          await prisma.apiCache.delete({ where: { key } });
        }
      }
    } catch (error) {
      console.error('Cache get error:', error);
    }

    return null;
  }

  // Set in both memory and DB cache
  static async set<T>(key: string, value: T, ttlSeconds: number): Promise<void> {
    // Set in memory cache
    memoryCache.set(key, value, { ttl: ttlSeconds * 1000 });

    // Set in DB cache
    try {
      await prisma.apiCache.upsert({
        where: { key },
        create: {
          key,
          valueJson: JSON.stringify(value),
          ttlSeconds,
          fetchedAt: new Date(),
        },
        update: {
          valueJson: JSON.stringify(value),
          ttlSeconds,
          fetchedAt: new Date(),
        },
      });
    } catch (error) {
      console.error('Cache set error:', error);
    }
  }

  // Delete from both caches
  static async delete(key: string): Promise<void> {
    memoryCache.delete(key);
    try {
      await prisma.apiCache.delete({ where: { key } });
    } catch (error) {
      // Ignore if not found
    }
  }

  // Clear expired entries from DB
  static async cleanupExpired(): Promise<void> {
    try {
      const now = new Date();
      const records = await prisma.apiCache.findMany();

      for (const record of records) {
        const expiresAt = new Date(record.fetchedAt).getTime() + record.ttlSeconds * 1000;
        if (Date.now() > expiresAt) {
          await prisma.apiCache.delete({ where: { id: record.id } });
        }
      }
    } catch (error) {
      console.error('Cache cleanup error:', error);
    }
  }

  // Generate cache keys
  static keys = {
    etfProfile: (ticker: string) => `etf:profile:${ticker}`,
    etfHoldings: (ticker: string) => `etf:holdings:${ticker}`,
    etfPrices: (ticker: string, range: string) => `etf:prices:${ticker}:${range}`,
    etfMetrics: (ticker: string) => `etf:metrics:${ticker}`,
    etfList: (params: string) => `etf:list:${params}`,
    benchmarkPrices: (ticker: string) => `benchmark:prices:${ticker}`,
  };
}
