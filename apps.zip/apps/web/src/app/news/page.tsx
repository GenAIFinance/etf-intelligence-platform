'use client';

import { useState } from 'react';
import { ExternalLink, Plus, X, Newspaper, Filter } from 'lucide-react';
import { useNewsList, useTrendingTopics } from '@/lib/hooks';
import { newsApi } from '@/lib/api';
import { formatDateTime } from '@/lib/utils';
import { TableSkeleton, CardSkeleton } from '@/components/ui/Skeleton';

export default function NewsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [tickerFilter, setTickerFilter] = useState('');
  const [page, setPage] = useState(1);
  const [showAddModal, setShowAddModal] = useState(false);

  const { data: news, isLoading, refetch } = useNewsList({
    query: searchQuery || undefined,
    ticker: tickerFilter || undefined,
    page,
    pageSize: 20,
  });

  const { data: trending } = useTrendingTopics();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Market News</h1>
          <p className="text-gray-600">
            Latest news with ETF impact analysis
          </p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="btn btn-primary flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Add News Manually
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-3 space-y-6">
          {/* Filters */}
          <div className="card">
            <div className="flex flex-wrap gap-4">
              <div className="flex-1 min-w-[200px]">
                <input
                  type="text"
                  placeholder="Search news..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setPage(1);
                  }}
                  className="input w-full"
                />
              </div>
              <div className="w-40">
                <input
                  type="text"
                  placeholder="Filter by ticker"
                  value={tickerFilter}
                  onChange={(e) => {
                    setTickerFilter(e.target.value.toUpperCase());
                    setPage(1);
                  }}
                  className="input w-full"
                />
              </div>
            </div>
          </div>

          {/* News List */}
          <div className="card">
            {isLoading ? (
              <TableSkeleton rows={10} />
            ) : !news?.data?.length ? (
              <div className="text-center py-12 text-gray-500">
                <Newspaper className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <p>No news found</p>
              </div>
            ) : (
              <div className="space-y-6">
                {news.data.map((item: any) => (
                  <div key={item.id} className="border-b pb-6 last:border-0 last:pb-0">
                    <div className="flex items-start gap-4">
                      <div className="flex-1">
                        <a
                          href={item.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-lg font-medium text-gray-900 hover:text-primary-600 flex items-start gap-2"
                        >
                          {item.title}
                          <ExternalLink className="w-4 h-4 mt-1 flex-shrink-0" />
                        </a>

                        <div className="flex items-center gap-2 mt-2 text-sm text-gray-500">
                          <span className="font-medium">{item.source}</span>
                          <span>•</span>
                          <span>{formatDateTime(item.publishedAt)}</span>
                        </div>

                        {item.snippet && (
                          <p className="mt-2 text-gray-600 text-sm line-clamp-2">
                            {item.snippet}
                          </p>
                        )}

                        {/* Topics */}
                        {item.topics?.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-3">
                            {item.topics.map((topic: any) => (
                              <span
                                key={topic.topicLabel}
                                className="badge badge-blue text-xs"
                              >
                                {topic.topicLabel}
                              </span>
                            ))}
                          </div>
                        )}

                        {/* Impacted ETFs */}
                        {item.impacts?.length > 0 && (
                          <div className="mt-3 bg-gray-50 rounded-lg p-3">
                            <div className="text-sm font-medium text-gray-700 mb-2">
                              Impacted ETFs:
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {item.impacts.slice(0, 5).map((impact: any) => (
                                <a
                                  key={impact.etfTicker}
                                  href={`/etf/${impact.etfTicker}`}
                                  className="inline-flex items-center gap-1 px-2 py-1 bg-white border border-gray-200 rounded text-sm hover:border-primary-500"
                                >
                                  <span className="font-medium">{impact.etfTicker}</span>
                                  <span className="text-primary-600">
                                    ({impact.impactScore.toFixed(1)})
                                  </span>
                                </a>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}

                {/* Pagination */}
                {news.totalPages > 1 && (
                  <div className="flex justify-center gap-2 pt-4">
                    <button
                      onClick={() => setPage((p) => Math.max(1, p - 1))}
                      disabled={page === 1}
                      className="btn btn-outline"
                    >
                      Previous
                    </button>
                    <span className="px-4 py-2 text-sm">
                      Page {page} of {news.totalPages}
                    </span>
                    <button
                      onClick={() => setPage((p) => Math.min(news.totalPages, p + 1))}
                      disabled={page >= news.totalPages}
                      className="btn btn-outline"
                    >
                      Next
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Trending Topics */}
          <div className="card">
            <h3 className="card-header">Trending Topics</h3>
            {trending?.topics?.length > 0 ? (
              <div className="space-y-2">
                {trending.topics.slice(0, 10).map((topic: any, i: number) => (
                  <button
                    key={topic.topic}
                    onClick={() => {
                      setSearchQuery(topic.topic);
                      setPage(1);
                    }}
                    className="w-full text-left p-2 rounded hover:bg-gray-50 flex items-center justify-between"
                  >
                    <span className="text-sm text-gray-700">{topic.topic}</span>
                    <span className="badge badge-gray text-xs">{topic.count}</span>
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-500">No trending topics</p>
            )}
          </div>
        </div>
      </div>

      {/* Add News Modal */}
      {showAddModal && (
        <AddNewsModal
          onClose={() => setShowAddModal(false)}
          onSuccess={() => {
            refetch();
            setShowAddModal(false);
          }}
        />
      )}
    </div>
  );
}

// Add News Modal
function AddNewsModal({
  onClose,
  onSuccess,
}: {
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [form, setForm] = useState({
    url: '',
    title: '',
    source: '',
    snippet: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      await newsApi.addManual(form);
      onSuccess();
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to add news item');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full">
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="text-lg font-semibold">Add News Manually</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              URL *
            </label>
            <input
              type="url"
              required
              value={form.url}
              onChange={(e) => setForm({ ...form, url: e.target.value })}
              className="input w-full"
              placeholder="https://..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Title *
            </label>
            <input
              type="text"
              required
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="input w-full"
              placeholder="Article headline"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Source *
            </label>
            <input
              type="text"
              required
              value={form.source}
              onChange={(e) => setForm({ ...form, source: e.target.value })}
              className="input w-full"
              placeholder="e.g., Bloomberg, Reuters"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Summary/Snippet
            </label>
            <textarea
              value={form.snippet}
              onChange={(e) => setForm({ ...form, snippet: e.target.value })}
              className="input w-full h-24 resize-none"
              placeholder="Brief summary of the article (do not paste full content)"
            />
          </div>

          {error && (
            <div className="text-red-500 text-sm">{error}</div>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <button type="button" onClick={onClose} className="btn btn-outline">
              Cancel
            </button>
            <button type="submit" disabled={loading} className="btn btn-primary">
              {loading ? 'Adding...' : 'Add News'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
