'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Search, TrendingUp, TrendingDown, ExternalLink, AlertCircle } from 'lucide-react';
import { useTopImpacted, useTrendingTopics, useEtfList } from '@/lib/hooks';
import { formatPercent, formatDateTime } from '@/lib/utils';
import { CardSkeleton } from '@/components/ui/Skeleton';

export default function Dashboard() {
  const [searchQuery, setSearchQuery] = useState('');
  const { data: topImpacted, isLoading: impactLoading } = useTopImpacted('7d');
  const { data: trending, isLoading: trendingLoading } = useTrendingTopics();
  const { data: etfResults } = useEtfList({
    search: searchQuery,
    pageSize: 5,
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">ETF Intelligence Dashboard</h1>
        <p className="text-gray-600">
          Track ETF performance, holdings exposure, and market-moving news
        </p>
      </div>

      {/* Search */}
      <div className="relative mb-8">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search ETFs by ticker or name..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-12 pr-4 py-3 text-lg border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
        />

        {/* Search Results Dropdown */}
        {searchQuery && etfResults?.data?.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-lg shadow-lg border border-gray-200 z-50 max-h-96 overflow-y-auto">
            {etfResults.data.map((etf: any) => (
              <Link
                key={etf.ticker}
                href={`/etf/${etf.ticker}`}
                className="flex items-center justify-between px-4 py-3 hover:bg-gray-50 border-b last:border-0"
                onClick={() => setSearchQuery('')}
              >
                <div>
                  <span className="font-semibold text-gray-900">{etf.ticker}</span>
                  <span className="text-gray-500 ml-2">{etf.name}</span>
                </div>
                <span className="badge badge-gray text-xs">{etf.assetClass}</span>
              </Link>
            ))}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Impacted ETFs */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-800">
              Top Impacted ETFs This Week
            </h2>
            <Link href="/news" className="text-primary-600 text-sm hover:underline">
              View all
            </Link>
          </div>

          {impactLoading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="skeleton h-16 rounded" />
              ))}
            </div>
          ) : topImpacted?.topEtfs?.length > 0 ? (
            <div className="space-y-3">
              {topImpacted.topEtfs.slice(0, 5).map((etf: any, index: number) => (
                <Link
                  key={etf.ticker}
                  href={`/etf/${etf.ticker}`}
                  className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 border border-gray-100"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 flex items-center justify-center bg-primary-100 text-primary-700 text-xs font-bold rounded">
                      {index + 1}
                    </span>
                    <div>
                      <span className="font-semibold text-gray-900">{etf.ticker}</span>
                      <p className="text-sm text-gray-500 truncate max-w-xs">{etf.name}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-gray-900">
                      Impact: {etf.totalImpactScore.toFixed(1)}
                    </div>
                    <div className="text-xs text-gray-500">{etf.newsCount} news items</div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <AlertCircle className="w-8 h-8 mx-auto mb-2 text-gray-400" />
              <p>No impact data available</p>
            </div>
          )}
        </div>

        {/* Trending Topics */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-800">Trending Topics</h2>
            <Link href="/news" className="text-primary-600 text-sm hover:underline">
              View all
            </Link>
          </div>

          {trendingLoading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="skeleton h-10 rounded" />
              ))}
            </div>
          ) : trending?.topics?.length > 0 ? (
            <div className="space-y-2">
              {trending.topics.slice(0, 8).map((topic: any, index: number) => (
                <div
                  key={topic.topic}
                  className="flex items-center justify-between p-3 rounded-lg bg-gray-50"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-lg font-bold text-gray-400">#{index + 1}</span>
                    <span className="font-medium text-gray-800">{topic.topic}</span>
                  </div>
                  <span className="badge badge-blue">{topic.count} mentions</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <AlertCircle className="w-8 h-8 mx-auto mb-2 text-gray-400" />
              <p>No trending topics</p>
            </div>
          )}
        </div>
      </div>

      {/* Quick Links */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
        <Link
          href="/etfs"
          className="card hover:shadow-md transition-shadow flex items-center gap-4"
        >
          <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center">
            <Search className="w-6 h-6 text-primary-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">ETF Screener</h3>
            <p className="text-sm text-gray-500">Search and filter ETFs</p>
          </div>
        </Link>

        <Link
          href="/etfs?assetClass=Equity"
          className="card hover:shadow-md transition-shadow flex items-center gap-4"
        >
          <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
            <TrendingUp className="w-6 h-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Equity ETFs</h3>
            <p className="text-sm text-gray-500">Browse equity funds</p>
          </div>
        </Link>

        <Link
          href="/news"
          className="card hover:shadow-md transition-shadow flex items-center gap-4"
        >
          <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
            <ExternalLink className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Market News</h3>
            <p className="text-sm text-gray-500">Latest news and impacts</p>
          </div>
        </Link>
      </div>
    </div>
  );
}
