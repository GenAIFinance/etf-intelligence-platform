'use client';

import { useState } from 'react';
import { useParams } from 'next/navigation';

// Mark this route as dynamic to avoid static generation errors
export const dynamic = 'force-dynamic';
import Link from 'next/link';
import {
  ChevronLeft,
  Download,
  TrendingUp,
  TrendingDown,
  BarChart3,
  PieChart,
  Layers,
  Newspaper,
  Info,
  ExternalLink,
} from 'lucide-react';
import {
  useEtf,
  useEtfHoldings,
  useEtfPrices,
  useEtfMetrics,
  useEtfThemesExposure,
  useEtfImpact,
} from '@/lib/hooks';
import {
  formatPercent,
  formatNumber,
  formatCurrency,
  formatDate,
  getReturnColor,
  downloadCSV,
  downloadJSON,
} from '@/lib/utils';
import { CardSkeleton, ChartSkeleton, TableSkeleton } from '@/components/ui/Skeleton';
import {
  PriceChart,
  ReturnsChart,
  SectorChart,
  ThemeExposureChart,
} from '@/components/charts/Charts';

type TabId = 'overview' | 'performance' | 'holdings' | 'themes' | 'news';

const TABS: { id: TabId; label: string; icon: React.ElementType }[] = [
  { id: 'overview', label: 'Overview', icon: Info },
  { id: 'performance', label: 'Performance', icon: TrendingUp },
  { id: 'holdings', label: 'Holdings', icon: Layers },
  { id: 'themes', label: 'Themes', icon: PieChart },
  { id: 'news', label: 'News Impact', icon: Newspaper },
];

export default function EtfDetailPage() {
  const params = useParams();
  const ticker = (params.ticker as string).toUpperCase();
  const [activeTab, setActiveTab] = useState<TabId>('overview');
  const [priceRange, setPriceRange] = useState('1y');

  const { data: etf, isLoading: etfLoading, error: etfError } = useEtf(ticker);
  const { data: holdings } = useEtfHoldings(ticker);
  const { data: prices } = useEtfPrices(ticker, priceRange);
  const { data: metrics } = useEtfMetrics(ticker);
  const { data: themes } = useEtfThemesExposure(ticker);
  const { data: impact } = useEtfImpact(ticker);

  if (etfError) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <Link href="/etfs" className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4">
          <ChevronLeft className="w-4 h-4" /> Back to screener
        </Link>
        <div className="card text-center py-12">
          <h2 className="text-xl font-semibold text-gray-800 mb-2">ETF Not Found</h2>
          <p className="text-gray-500">The ticker "{ticker}" was not found.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Breadcrumb */}
      <Link
        href="/etfs"
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
      >
        <ChevronLeft className="w-4 h-4" /> Back to screener
      </Link>

      {/* Header */}
      {etfLoading ? (
        <CardSkeleton />
      ) : (
        <div className="card mb-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-3xl font-bold text-gray-900">{ticker}</h1>
                {etf?.assetClass && (
                  <span className="badge badge-blue">{etf.assetClass}</span>
                )}
                {etf?.strategyType && (
                  <span className="badge badge-gray">{etf.strategyType}</span>
                )}
              </div>
              <p className="text-gray-600">{etf?.name}</p>
            </div>
            {metrics?.technicals?.latestPrice && (
              <div className="text-right">
                <div className="text-3xl font-bold text-gray-900">
                  ${metrics.technicals.latestPrice.toFixed(2)}
                </div>
                {metrics?.trailingReturns?.['1M'] !== null && metrics?.trailingReturns?.['1M'] !== undefined && (
                  <div
                    className={`text-sm font-medium ${getReturnColor(
                      metrics.trailingReturns['1M']
                    )}`}
                  >
                    {metrics.trailingReturns['1M'] >= 0 ? '+' : ''}
                    {formatPercent(metrics.trailingReturns['1M'])} (1M)
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <div className="flex gap-1 overflow-x-auto">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`tab flex items-center gap-2 whitespace-nowrap ${
                  activeTab === tab.id ? 'tab-active' : ''
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <OverviewTab etf={etf} metrics={metrics} holdings={holdings} />
      )}
      {activeTab === 'performance' && (
        <PerformanceTab
          ticker={ticker}
          prices={prices}
          metrics={metrics}
          priceRange={priceRange}
          setPriceRange={setPriceRange}
        />
      )}
      {activeTab === 'holdings' && (
        <HoldingsTab ticker={ticker} holdings={holdings} />
      )}
      {activeTab === 'themes' && <ThemesTab ticker={ticker} themes={themes} />}
      {activeTab === 'news' && <NewsTab ticker={ticker} impact={impact} />}
    </div>
  );
}

// Overview Tab
function OverviewTab({ etf, metrics, holdings }: any) {
  if (!etf) return <CardSkeleton />;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Fund Summary */}
      <div className="card">
        <h3 className="card-header">Fund Summary</h3>
        {etf.summary ? (
          <p className="text-gray-700 text-sm leading-relaxed">{etf.summary}</p>
        ) : (
          <p className="text-gray-500 italic">No summary available</p>
        )}

        {etf.llmSummary && (
          <div className="mt-4 pt-4 border-t">
            <h4 className="font-medium text-gray-800 mb-2">AI Analysis</h4>
            <div className="space-y-2 text-sm">
              <p>
                <strong>What it owns:</strong> {etf.llmSummary.whatItOwns}
              </p>
              <p>
                <strong>Risk profile:</strong> {etf.llmSummary.riskProfile}
              </p>
              {etf.llmSummary.keySensitivities?.length > 0 && (
                <div>
                  <strong>Key sensitivities:</strong>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {etf.llmSummary.keySensitivities.map((s: string) => (
                      <span key={s} className="badge badge-gray text-xs">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Key Stats */}
      <div className="card">
        <h3 className="card-header">Key Statistics</h3>
        <div className="grid grid-cols-2 gap-4">
          <StatItem label="AUM" value={formatCurrency(etf.aum)} />
          <StatItem
            label="Inception Date"
            value={etf.inceptionDate ? formatDate(etf.inceptionDate) : 'N/A'}
          />
          <StatItem
            label="Annual Turnover"
            value={etf.turnover ? formatPercent(etf.turnover) : 'N/A'}
          />
          <StatItem label="Exchange" value={etf.exchange} />
          <StatItem label="Currency" value={etf.currency} />
          <StatItem label="Country" value={etf.country} />
        </div>
      </div>

      {/* Sector Weights */}
      <div className="card">
        <h3 className="card-header">Sector Allocation</h3>
        {etf.sectorWeights?.length > 0 ? (
          <SectorChart
            sectors={etf.sectorWeights.map((s: any) => ({
              sector: s.sector,
              weight: s.weight,
            }))}
          />
        ) : (
          <p className="text-gray-500 text-center py-8">No sector data available</p>
        )}
      </div>

      {/* Concentration */}
      <div className="card">
        <h3 className="card-header">Concentration Metrics</h3>
        {holdings?.concentration ? (
          <div className="grid grid-cols-3 gap-4">
            <StatItem
              label="Top 10 Weight"
              value={formatPercent(holdings.concentration.top10Weight)}
            />
            <StatItem
              label="HHI"
              value={formatNumber(holdings.concentration.hhi * 10000, 0)}
            />
            <StatItem
              label="Holdings Count"
              value={holdings.concentration.totalHoldings.toString()}
            />
          </div>
        ) : (
          <p className="text-gray-500 text-center py-8">
            No concentration data available
          </p>
        )}
      </div>
    </div>
  );
}

// Performance Tab
function PerformanceTab({ ticker, prices, metrics, priceRange, setPriceRange }: any) {
  return (
    <div className="space-y-6">
      {/* Price Chart */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="card-header mb-0">Price Chart</h3>
          <div className="flex gap-1">
            {['1m', '3m', '6m', '1y', '3y', '5y'].map((range) => (
              <button
                key={range}
                onClick={() => setPriceRange(range)}
                className={`px-3 py-1 text-sm rounded ${
                  priceRange === range
                    ? 'bg-primary-100 text-primary-700'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {range.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
        {prices?.prices?.length > 0 ? (
          <PriceChart data={prices.prices} range={priceRange} />
        ) : (
          <ChartSkeleton />
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Trailing Returns */}
        <div className="card">
          <h3 className="card-header">Trailing Returns</h3>
          {metrics?.trailingReturns ? (
            <ReturnsChart returns={metrics.trailingReturns} />
          ) : (
            <ChartSkeleton />
          )}
        </div>

        {/* Risk Metrics */}
        <div className="card">
          <h3 className="card-header">Risk Metrics</h3>
          {metrics?.riskMetrics ? (
            <div className="grid grid-cols-2 gap-4">
              <StatItem
                label="Volatility (Ann.)"
                value={formatPercent(metrics.riskMetrics.volatility)}
              />
              <StatItem
                label="Sharpe Ratio"
                value={formatNumber(metrics.riskMetrics.sharpe)}
              />
              <StatItem
                label="Max Drawdown"
                value={formatPercent(metrics.riskMetrics.maxDrawdown)}
              />
              <StatItem
                label="Beta (vs SPY)"
                value={formatNumber(metrics.riskMetrics.beta)}
              />
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8">
              No risk data available
            </p>
          )}
        </div>

        {/* Technical Indicators */}
        <div className="card lg:col-span-2">
          <h3 className="card-header">Technical Snapshot</h3>
          {metrics?.technicals ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <StatItem
                label="Latest Price"
                value={`$${formatNumber(metrics.technicals.latestPrice)}`}
              />
              <StatItem
                label="52W High"
                value={`$${formatNumber(metrics.technicals.hi52w)}`}
              />
              <StatItem
                label="52W Low"
                value={`$${formatNumber(metrics.technicals.lo52w)}`}
              />
              <StatItem
                label="RSI (14)"
                value={formatNumber(metrics.technicals.rsi14)}
              />
              <StatItem
                label="MA (20)"
                value={`$${formatNumber(metrics.technicals.ma20)}`}
              />
              <StatItem
                label="MA (50)"
                value={`$${formatNumber(metrics.technicals.ma50)}`}
              />
              <StatItem
                label="MA (200)"
                value={`$${formatNumber(metrics.technicals.ma200)}`}
              />
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8">
              No technical data available
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

// Holdings Tab
function HoldingsTab({ ticker, holdings }: any) {
  if (!holdings) return <TableSkeleton rows={10} />;

  const handleExportCSV = () => {
    const data = holdings.holdings.map((h: any) => ({
      Ticker: h.holdingTicker,
      Name: h.holdingName,
      Weight: (h.weight * 100).toFixed(2) + '%',
      Sector: h.sector || 'N/A',
      Industry: h.industry || 'N/A',
    }));
    downloadCSV(data, `${ticker}_holdings.csv`);
  };

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <h3 className="card-header mb-0">
          All Holdings ({holdings.holdings?.length || 0})
        </h3>
        <button onClick={handleExportCSV} className="btn btn-outline flex items-center gap-2">
          <Download className="w-4 h-4" />
          Export CSV
        </button>
      </div>

      <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
        <table>
          <thead className="sticky top-0 bg-gray-50">
            <tr>
              <th>#</th>
              <th>Ticker</th>
              <th>Name</th>
              <th className="text-right">Weight</th>
              <th>Sector</th>
              <th>Industry</th>
            </tr>
          </thead>
          <tbody>
            {holdings.holdings?.map((h: any, i: number) => (
              <tr key={h.holdingTicker}>
                <td className="text-gray-400">{i + 1}</td>
                <td className="font-medium">{h.holdingTicker}</td>
                <td className="max-w-xs truncate" title={h.holdingName}>
                  {h.holdingName}
                </td>
                <td className="text-right font-mono">{formatPercent(h.weight)}</td>
                <td>
                  <span className="badge badge-blue text-xs">{h.sector || 'N/A'}</span>
                </td>
                <td className="text-gray-500 text-sm">{h.industry || 'N/A'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Themes Tab
function ThemesTab({ ticker, themes }: any) {
  const [selectedTheme, setSelectedTheme] = useState<string | null>(null);

  if (!themes) return <CardSkeleton />;

  const selectedThemeData = themes.exposures?.find(
    (t: any) => t.themeId === selectedTheme
  );

  const handleExportJSON = () => {
    downloadJSON(themes, `${ticker}_themes.json`);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Theme Exposures Chart */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="card-header mb-0">Theme Exposures</h3>
          <button onClick={handleExportJSON} className="btn btn-outline flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export JSON
          </button>
        </div>
        {themes.exposures?.length > 0 ? (
          <ThemeExposureChart
            exposures={themes.exposures.map((t: any) => ({
              themeName: t.themeName,
              exposure: t.exposure,
            }))}
          />
        ) : (
          <p className="text-gray-500 text-center py-8">No theme exposure data</p>
        )}
      </div>

      {/* Theme List */}
      <div className="card">
        <h3 className="card-header">Theme Breakdown</h3>
        {themes.exposures?.length > 0 ? (
          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {themes.exposures.map((t: any) => (
              <button
                key={t.themeId}
                onClick={() =>
                  setSelectedTheme(selectedTheme === t.themeId ? null : t.themeId)
                }
                className={`w-full text-left p-3 rounded-lg border transition-colors ${
                  selectedTheme === t.themeId
                    ? 'border-primary-500 bg-primary-50'
                    : 'border-gray-200 hover:bg-gray-50'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className="font-medium text-gray-900">{t.themeName}</span>
                  <span className="badge badge-blue">{formatPercent(t.exposure)}</span>
                </div>
                <div className="text-sm text-gray-500 mt-1">
                  {t.holdings?.length || 0} holdings
                </div>
              </button>
            ))}
          </div>
        ) : (
          <p className="text-gray-500 text-center py-8">No themes identified</p>
        )}
      </div>

      {/* Selected Theme Holdings */}
      {selectedThemeData && (
        <div className="card lg:col-span-2">
          <h3 className="card-header">
            Holdings in "{selectedThemeData.themeName}"
          </h3>
          <div className="overflow-x-auto">
            <table>
              <thead>
                <tr>
                  <th>Ticker</th>
                  <th>Name</th>
                  <th className="text-right">Weight</th>
                  <th className="text-right">Confidence</th>
                </tr>
              </thead>
              <tbody>
                {selectedThemeData.holdings?.map((h: any) => (
                  <tr key={h.ticker}>
                    <td className="font-medium">{h.ticker}</td>
                    <td>{h.name}</td>
                    <td className="text-right font-mono">{formatPercent(h.weight)}</td>
                    <td className="text-right font-mono">
                      {formatPercent(h.confidence)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// News Tab
function NewsTab({ ticker, impact }: any) {
  if (!impact) return <CardSkeleton />;

  return (
    <div className="card">
      <h3 className="card-header">News Impacting {ticker}</h3>

      {impact.impacts?.length > 0 ? (
        <div className="space-y-4">
          {impact.impacts.map((item: any, i: number) => (
            <div key={i} className="border-b pb-4 last:border-0 last:pb-0">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <a
                    href={item.newsItem.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-medium text-gray-900 hover:text-primary-600 flex items-center gap-1"
                  >
                    {item.newsItem.title}
                    <ExternalLink className="w-3 h-3" />
                  </a>
                  <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                    <span>{item.newsItem.source}</span>
                    <span>•</span>
                    <span>{formatDate(item.newsItem.publishedAt)}</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-primary-600">
                    Impact: {item.impactScore.toFixed(1)}
                  </div>
                </div>
              </div>

              {/* Impact Details */}
              <div className="mt-3 bg-gray-50 rounded-lg p-3 text-sm">
                <p className="text-gray-700 mb-2">{item.rationale}</p>
                <div className="flex flex-wrap gap-2">
                  {item.matchedHoldings?.length > 0 && (
                    <div>
                      <span className="text-gray-500">Holdings:</span>
                      {item.matchedHoldings.map((h: string) => (
                        <span key={h} className="badge badge-blue ml-1">
                          {h}
                        </span>
                      ))}
                    </div>
                  )}
                  {item.matchedThemes?.length > 0 && (
                    <div>
                      <span className="text-gray-500">Themes:</span>
                      {item.matchedThemes.map((t: string) => (
                        <span key={t} className="badge badge-gray ml-1">
                          {t}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Topics */}
              {item.newsItem.topics?.length > 0 && (
                <div className="flex gap-1 mt-2">
                  {item.newsItem.topics.map((topic: string) => (
                    <span key={topic} className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded">
                      {topic}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-500 text-center py-8">
          No news impacts found for this ETF
        </p>
      )}
    </div>
  );
}

// Stat Item Component
function StatItem({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-sm text-gray-500">{label}</div>
      <div className="font-semibold text-gray-900">{value}</div>
    </div>
  );
}
